import os

class Path(object):
    @staticmethod
    def base_root():
        base_dir = 'C:\\Users\\지선\\Desktop\\atp_class2'

        return base_dir

    @staticmethod
    def data_root():
        base_dir = 'C:\\Users\\지선\\Desktop\\atp_class2'
        data_dir = os.path.join(base_dir, 'data/AI_hub')

        return data_dir