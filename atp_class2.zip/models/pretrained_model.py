
from torchvision.models.segmentation.deeplabv3 import DeepLabHead
from torchvision import models
from torchvision.models.segmentation.fcn import FCNHead
import segmentation_models_pytorch as smp
import torch

def createDeepLabv3(n_class=6):

    model = models.segmentation.deeplabv3_resnet50(pretrained=True, progress=True)
    model.classifier = DeepLabHead(2048, n_class)

    return model


def createFCN(n_class=6):

    model = models.segmentation.fcn_resnet50(pretrained=True, progress=True)
    model.classifier = FCNHead(2048, n_class)

    return model


def createUnet(n_class=6):

    model = smp.Unet(
        encoder_name="resnet50",
        encoder_weights="imagenet",
        in_channels=3,
        classes=n_class,
    )
    return model


def createUnetplusplus(n_class=6):
    model = smp.UnetPlusPlus(
        encoder_name="resnet50",
        encoder_weights="imagenet",
        in_channels=3,
        classes=n_class,
    )
    return model


def createPSPNet(n_class=6):

    model = smp.PSPNet(
        encoder_name="resnet50",
        encoder_weights="imagenet",
        in_channels=3,
        classes=n_class,
    )
    return model
