
from models.fcn8s import FCN8s
from models.fcn16s import FCN16s
from models.fcn32s import FCN32s
from models.unet import Unet
from models.segnet import SegNet
from models.pretrained_model import createDeepLabv3, createFCN, createUnet, createUnetplusplus, createPSPNet


def load_segmentation_models(model_name, num_class):

    if model_name == 'fcn8':
        return FCN8s(n_class=num_class)
    elif model_name == 'fcn16':
        return FCN16s(n_class=num_class)
    elif model_name == 'fcn32':
        return FCN32s(n_class=num_class)
    elif model_name == 'unet':
        return Unet(num_classes=num_class)
    elif model_name == 'segnet':
        return SegNet(num_classes=num_class)
    elif model_name == 'pre_fcn32':
        return createFCN(n_class=num_class)
    elif model_name == 'pre_deeplabv3':
        return createDeepLabv3(n_class=num_class)
    elif model_name == 'pre_Unet':
        return createUnet(n_class=num_class)
    elif model_name == 'pre_Unetplusplus':
        return createUnetplusplus(n_class=num_class)
    elif model_name == 'pre_PSPNet':
        return createPSPNet(n_class=num_class)


