import matplotlib.pyplot as plt
import numpy as np
import torch


def decode_seg_map_sequence(label_masks, dataset):
    rgb_masks = []
    for label_mask in label_masks:
        rgb_mask = decode_segmap(label_mask, dataset)
        rgb_masks.append(rgb_mask)
    rgb_masks = torch.from_numpy(np.array(rgb_masks).transpose([0, 3, 1, 2]))
    return rgb_masks


def decode_segmap(label_mask, dataset='buildings', plot=False):
    """Decode segmentation class labels into a color image
    Args:
        label_mask (np.ndarray): an (M,N) array of integer values denoting
          the class label at each spatial location.
        plot (bool, optional): whether to show the resulting color image
          in a figure.
    Returns:
        (np.ndarray, optional): the resulting decoded color image.
    """
    if dataset == 'buildings':

        label_name = ["background", "building"]
#                       "small_building",
#                       "factory",
#                       "apt",
#                       "large_building",
#                       "mid_building"]

        n_classes = int(len(label_name))
        label_colours = get_car_labels()

    else:
        raise NotImplementedError

    r = label_mask.copy()
    g = label_mask.copy()
    b = label_mask.copy()
    for ll in range(0, n_classes):
        # ll=0
        r[label_mask == ll] = label_colours[ll, 0]
        g[label_mask == ll] = label_colours[ll, 1]
        b[label_mask == ll] = label_colours[ll, 2]

    rgb = np.dstack([r, g, b])
    rgb = np.uint8(rgb)
    if plot:
        plt.imshow(rgb)
        plt.show()
    else:
        return rgb


def get_car_labels():
    """Load the mapping that associates pascal classes with label colors
    Returns:
        np.ndarray with dimensions (2, 3)
    """
    return np.asarray([
        [0, 0, 0], [255, 255, 255]])  # 배경(0): (0,0,0) 검정
#         [0, 0, 255],  # 소형건물(1): (0, 0, 225) 파랑
#         [255, 0, 0],  # 공장(3): (225, 0, 0) 빨강
#         [0, 255, 0],  # 아파트(2): (0, 255, 0) 라임
#         [0, 255, 255],  # 대형건물(5): (0, 225, 225) 아쿠아
#         [255, 255, 0]  # 중형건물(4): (225, 225, 0) 노랑
#     ])