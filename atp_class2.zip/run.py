import torch
from utils_.args import segmentation_parser
from dataloaders import make_data_loaders
from utils_.mypath import Path
from models.load_model import load_segmentation_models
import torch.optim as optim
from tqdm import tqdm
import numpy as np
import random
from itertools import product
import os
import pandas as pd
# import wandb
from utils_.metrics import Evaluator
from utils_.calculate_weights import calculate_weights_labels
from utils_.loss import SegmentationLosses
from utils_.label_decode import decode_segmap
import matplotlib.pyplot as plt

import warnings
warnings.filterwarnings("ignore")


def main(model:str, args):
    # define parser



    # reproducibility
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    np.random.seed(args.seed)
    random.seed(args.seed)

    args.model_name = model


    # wandb
#     wandb.init(project="ATP_Experiment", reinit=True)
#     wandb.run.name = f'model_{args.model_name}_loss_{args.loss_type}_classweight_{str(args.use_balanced_weights)}'
#     wandb.save()


    # define data loader
    train_loader, valid_loader, test_loader = make_data_loaders(args)
    # inputs, targets, file_names = next(iter(test_loader))


    # define model
    model = load_segmentation_models(model_name=args.model_name, num_class=args.n_class)
    model.to(args.cuda)

    def get_lr(optimizer):
        for param_group in optimizer.param_groups:
            return param_group['lr']

    def train(net, data_loader, train_optimizer, epoch, args):
        net.train()
        evaluator.reset()

        total_loss, total_num, train_bar = 0.0, 0, tqdm(data_loader)
        for inputs, targets, _ in train_bar:

            targets = targets.long()
            inputs, targets = inputs.to(args.cuda), targets.to(args.cuda)


            outputs = net(inputs)

            loss = criterion(outputs['out'], targets)

            targets = targets.cpu().numpy()
            _, predict = torch.max(outputs['out'], dim=1)
            pred = predict.cpu().numpy()

            evaluator.add_batch(targets, pred)

            pixel_acc = evaluator.Pixel_Accuracy()
            mean_acc = evaluator.Pixel_Accuracy_Class()
            mean_iou = evaluator.Mean_Intersection_over_Union()
            fw_iou = evaluator.Frequency_Weighted_Intersection_over_Union()


            train_optimizer.zero_grad()
            loss.backward()
            train_optimizer.step()
            scheduler.step()

            total_num += data_loader.batch_size
            total_loss += loss.item() * data_loader.batch_size

            train_bar.set_description(
                'Train Epoch: [{}/{}], lr: {:.6f}, Loss: {:.4f}, pixel_acc: {:.4f}, mean_acc: {:.4f}, mIoU: {:.4f}, fwIoU: {:.4f}'.format(
                    epoch,
                    args.epochs,
                    get_lr(train_optimizer),
                    total_loss / total_num,
                    pixel_acc,
                    mean_acc,
                    mean_iou,
                    fw_iou))

        return total_loss / total_num, pixel_acc, mean_acc, mean_iou, fw_iou

    def validation(net, data_loader, evaluator, epoch, args):
        net.eval()
        evaluator.reset()

        total_loss, total_num, valid_bar = 0.0, 0, tqdm(data_loader)
        for inputs, targets, _ in valid_bar:

            targets = targets.long()
            inputs, targets = inputs.to(args.cuda), targets.to(args.cuda)

            outputs = net(inputs)
            # outputs = outputs['out']

            loss = criterion(outputs['out'], targets)

            targets = targets.cpu().numpy()
            _, predict = torch.max(outputs['out'], dim=1)
            pred = predict.cpu().numpy()

            evaluator.add_batch(targets, pred)


            pixel_acc = evaluator.Pixel_Accuracy()
            mean_acc = evaluator.Pixel_Accuracy_Class()
            mean_iou = evaluator.Mean_Intersection_over_Union()
            fw_iou = evaluator.Frequency_Weighted_Intersection_over_Union()


            total_num += data_loader.batch_size
            total_loss += loss.item() * data_loader.batch_size
            valid_bar.set_description('Valid Epoch: [{}/{}], Loss: {:.4f}, pixel_acc: {:.4f}, mean_acc: {:.4f}, mIoU: {:.4f}, fwIoU: {:.4f}'.format(epoch,
                                                                                                                                                     args.epochs,
                                                                                                                                                     total_loss / total_num,
                                                                                                                                                     pixel_acc,
                                                                                                                                                     mean_acc,
                                                                                                                                                     mean_iou,
                                                                                                                                                     fw_iou))
        return total_loss / total_num, pixel_acc, mean_acc, mean_iou, fw_iou

    def test(net, data_loader, evaluator, args):
        net.eval()
        evaluator.reset()

        total_loss, total_num, test_bar = 0.0, 0, tqdm(data_loader)
        for inputs, targets, file_names in test_bar:

            targets = targets.long()
            inputs, targets = inputs.to(args.cuda), targets.to(args.cuda)

            outputs = net(inputs)

            targets = targets.cpu().numpy()
            _, predict = torch.max(outputs['out'], dim=1)
            pred = predict.cpu().numpy()

            evaluator.add_batch(targets, pred)

            pixel_acc = evaluator.Pixel_Accuracy()
            mean_acc = evaluator.Pixel_Accuracy_Class()
            mean_iou = evaluator.Mean_Intersection_over_Union()
            fw_iou = evaluator.Frequency_Weighted_Intersection_over_Union()

            new_targets = decode_segmap(targets.squeeze(), dataset=args.object_type)
            new_preds = decode_segmap(pred.squeeze(), dataset=args.object_type)

            # save plot
            plt.imsave(os.path.join(args.plot_dir, f"{file_names[0]}_target.png"), new_targets)
            plt.imsave(os.path.join(args.plot_dir, f"{file_names[0]}_pred.png"), new_preds)

            test_bar.set_description(
                'Test Epoch: [{}/{}], pixel_acc: {:.4f}, mean_acc: {:.4f}, mIoU: {:.4f}, fwIoU: {:.4f}'.format(
                    epoch,
                    args.epochs,
                    pixel_acc,
                    mean_acc,
                    mean_iou,
                    fw_iou))

        return pixel_acc, mean_acc, mean_iou, fw_iou

    # %% training setting
    if args.use_balanced_weights:
        classes_weights_path = os.path.join(Path.data_root(),
                                            "train",
                                            "samples",
                                            f"train_{args.object_type}_data",
                                            f"label_weights.npy")
        if os.path.isfile(classes_weights_path):
            weight = np.load(classes_weights_path)
        else:
            weight = calculate_weights_labels(split="train",
                                              obj_type=args.object_type,
                                              dataloader=train_loader,
                                              num_classes=args.n_class)
        weight = torch.from_numpy(weight.astype(np.float32))

    else:
        weight = None

    # criterion = nn.CrossEntropyLoss()
    criterion = SegmentationLosses(weight=weight, cuda=args.cuda).build_loss(mode=args.loss_type)
    optimizer = optim.SGD(model.parameters(), lr=args.lr, momentum=args.momentum, weight_decay=args.weight_decay)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs, eta_min=0.0001)
    evaluator = Evaluator(num_class=args.n_class)
    best_loss = np.inf

    # %% logging
    results = {'train_loss': [], 'train_acc': [], 'train_macc': [], 'train_miou': [], 'train_fwiou': [],
               'valid_loss': [], 'valid_acc': [], 'valid_macc': [], 'valid_miou': [], 'valid_fwiou': [],
               'test_acc': [], 'test_macc': [], 'test_miou': [], 'test_fwiou': []}

    args.results_dir = os.path.join(args.results_dir,
                                    args.model_name,
                                    args.object_type,
                                    args.loss_type,
                                    f"weights_{str(args.use_balanced_weights)}")

    if not os.path.exists(args.results_dir):
        os.makedirs(args.results_dir, exist_ok=True)

    args.plot_dir = os.path.join(args.results_dir, "plot")

    if not os.path.exists(args.plot_dir):
        os.makedirs(args.plot_dir, exist_ok=True)

    # %% training run !
    epoch_start = 1
    for epoch in range(epoch_start, args.epochs + 1):

        train_loss, train_pixel_acc, train_mean_acc, train_mean_iou, train_fw_iou = train(model, train_loader, optimizer, epoch, args)
        results['train_loss'].append(train_loss)
        results['train_acc'].append(train_pixel_acc)
        results['train_macc'].append(train_mean_acc)
        results['train_miou'].append(train_mean_iou)
        results['train_fwiou'].append(train_fw_iou)


        valid_loss, valid_pixel_acc, valid_mean_acc, valid_mean_iou, valid_fw_iou = validation(model, valid_loader, evaluator, epoch, args)
        results['valid_loss'].append(valid_loss)
        results['valid_acc'].append(valid_pixel_acc)
        results['valid_macc'].append(valid_mean_acc)
        results['valid_miou'].append(valid_mean_iou)
        results['valid_fwiou'].append(valid_fw_iou)

        if valid_loss < best_loss:
            test_pixel_acc, test_mean_acc, test_mean_iou, test_fw_iou = test(model, test_loader, evaluator, args)

            torch.save({'epoch': epoch, 'state_dict': model.state_dict(), 'optimizer': optimizer.state_dict()},
                       args.results_dir + '/model_last.pth')

            best_loss = valid_loss

        results['test_acc'].append(test_pixel_acc)
        results['test_macc'].append(test_mean_acc)
        results['test_miou'].append(test_mean_iou)
        results['test_fwiou'].append(test_fw_iou)


#         wandb.log({
#             "Train Loss": train_loss,
#             "Valid Loss": valid_loss,
#             "valid_acc": valid_pixel_acc,
#             "valid_macc": valid_mean_acc,
#             "valid_miou": valid_mean_iou,
#             "valid_fwiou": valid_fw_iou,
#             "test_acc": test_pixel_acc,
#             "test_macc": test_mean_acc,
#             "test_miou": test_mean_iou,
#             "test_fwiou": test_fw_iou,

#         }, step=epoch)

        # save statistics
        data_frame = pd.DataFrame(data=results, index=range(epoch_start, epoch + 1))
        data_frame.to_csv(args.results_dir + f'/log_epoch_{str(epoch)}_acc{str(round(test_pixel_acc, 3))}_miou{str(round(test_mean_iou, 3))}.csv',
                          index_label='epoch')


if __name__ == "__main__":
    parser = segmentation_parser()
    args = parser.parse_args('')
    args.cuda = torch.device('cuda:0')
    args.n_class = 2
    args.epochs = 200
    args.use_balanced_weights = False

    model_type = ["pre_deeplabv3", "pre_fcn32"]

    params = list(product(model_type))

    for p in params:
        main(p[0], args)
