import argparse

def segmentation_parser():
    parser = argparse.ArgumentParser(description='PyTorch Semantic Segmentation Training')

    # data type
    parser.add_argument('--object_type', type=str, default='buildings',
                        choices=['buildings', 'roads'], help='Object type')

    # data loader
    parser.add_argument('--original_size', type=int, default=1024, help='raw data size')
    parser.add_argument('--crop_size', type=int, default=512, help='crop data size')
    parser.add_argument('--scale', type=int, default=True, help='input data scaling boolean')
    parser.add_argument('--valid_ratio', type=float, default=0.1, help='validation set ratio')
    parser.add_argument('--shuffle_dataset', type=bool, default=True)

    # model type selection
    parser.add_argument('--n_class', type=int, default=6, help='# of class')
    parser.add_argument('--model_name', type=str, default="pre_deeplabv3",
                        choices=["fcn8", "fcn16", "fcn32", "pre_fcn32", "pre_deeplabv3", "pre_Unet", "pre_Unetplusplus", "pre_PSPNet"],
                        help='segmentation models')

    # training hyperparameters
    parser.add_argument('--epochs', type=int, default=100,
                        help='number of epochs to train (default: auto)')
    parser.add_argument('--batch-size', type=int, default=2,
                        metavar='N', help='input batch size for training (default: auto)')
    parser.add_argument('--test-batch-size', type=int, default=1,
                        metavar='N', help='input batch size for training (default: auto)')


    # optimizer parameters
    parser.add_argument('--lr', type=float, default=1e-3,
                        help='learning rate (default: auto)')
    parser.add_argument('--weight-decay', type=float, default=1e-2,
                        metavar='M', help='weight decay (default: 5e-4)')
    parser.add_argument('--momentum', type=float, default=0.9)
    parser.add_argument('--use_balanced_weights', type=int, default=False,
                        choices=[True, False])
    parser.add_argument('--loss_type', type=str, default="ce",
                        choices=["ce", "focal"])


    # cuda, seed and logging
    parser.add_argument('--seed', type=int, default=2021,
                        help='random seed (default: 1)')
    parser.add_argument('--results_dir', type=str, default='./results')


    return parser