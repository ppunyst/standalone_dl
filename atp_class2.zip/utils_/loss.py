import torch
import torch.nn as nn
import torch.functional as F
from utils_.losses import ComboLoss


class SegmentationLosses(object):
    def __init__(self, cuda, weight=None, batch_average=False, ignore_index=255):
        self.weight = weight
        self.batch_average = batch_average
        self.ignore_index = ignore_index
        self.cuda = cuda

    def build_loss(self, mode='ce'):
        """Choices: ['ce' or 'focal']"""
        if mode == 'ce':
            return self.CrossEntropyLoss

        elif mode == 'focal':
            return self.FocalLoss
        
        elif mode == "nll":
            return self.NLLLoss

        elif mode == "bce":
            return self.BCELoss

        # elif mode == "combo":
        #     return ComboLoss({'dice': 1, 'focal': 1}, per_image=True)

        else:
            raise NotImplementedError
        
    def CrossEntropyLoss(self, logit, target):
        #print("logit ", logit)
        #print("logit size ", logit.size())
        #n, c, h, w = logit.size()
        criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index)

        criterion = criterion.to(device=self.cuda)

        loss = criterion(logit, target.long())


        return loss

    def NLLLoss(self, logit, target):
        n, c, h, w = logit.size()
        criterion = nn.NLLLoss(weight=self.weight, ignore_index=self.ignore_index)
        criterion = criterion.to(device=self.cuda)
        
        loss = criterion(logit, target.long())
        return (-1)*loss


    def BCELoss(self, logit, target):
        n, c, h, w = logit.size()
        criterion = nn.BCELoss(weight=self.weight)
        criterion = criterion.to(device=self.cuda)

        loss = criterion(logit, target.long())
        return loss

    def FocalLoss(self, logit, target, gamma=2, alpha=0.5):
        # n, c, h, w = logit.size()
        criterion = nn.CrossEntropyLoss(weight=self.weight, ignore_index=self.ignore_index)

        criterion = criterion.to(device=self.cuda)

        logpt = -criterion(logit, target.long())
        pt = torch.exp(logpt)

        if alpha is not None:
            logpt *= alpha

        loss = -((1 - pt) ** gamma) * logpt

        return loss


if __name__ == "__main__":
    cuda = torch.device('cuda:0')
    criterion = SegmentationLosses(weight=None, cuda=cuda).build_loss(mode="ce")
    a = torch.rand(1, 3, 7, 7).to(device=cuda)
    b = torch.rand(1, 7, 7).to(device=cuda)
    print(criterion(a,b))

import torch.nn.functional as F


def dice_loss(pred, target, smooth=1e-5):
    # binary cross entropy loss
    bce = F.binary_cross_entropy_with_logits(pred, target, reduction='sum')

    pred = torch.sigmoid(pred)
    intersection = (pred * target).sum(dim=(2, 3))
    union = pred.sum(dim=(2, 3)) + target.sum(dim=(2, 3))

    # dice coefficient
    dice = 2.0 * (intersection + smooth) / (union + smooth)

    # dice loss
    dice_loss = 1.0 - dice

    # total loss
    loss = bce + dice_loss

    return loss.sum(), dice.sum()