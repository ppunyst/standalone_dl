from dataloaders.datasets import aihub_dataset
from torch.utils.data import DataLoader
from torchvision import transforms
import numpy as np
from torch.utils.data.sampler import SubsetRandomSampler
import torch

def make_data_loaders(args):

    img_mean = np.array((128, 128, 128), dtype=np.float32)

    trainset = aihub_dataset.AI_HUB_Dataset(args=args, split='train', original_size=[args.original_size, args.original_size], crop_size=[args.crop_size, args.crop_size], mean=img_mean, scale=args.scale)
    testset = aihub_dataset.AI_HUB_Dataset(args=args, split='test', original_size=[args.original_size, args.original_size], crop_size=[args.crop_size, args.crop_size], mean=img_mean, scale=args.scale)

    # Creating data indices for training and validation splits:
    dataset_size = len(trainset)
    indices = list(range(dataset_size))
    split = int(np.floor(args.valid_ratio * dataset_size))
    if args.shuffle_dataset:
        np.random.seed(args.seed)
        np.random.shuffle(indices)
    train_indices, val_indices = indices[split:], indices[:split]

    # Creating PT data samplers and loaders:
    train_sampler = SubsetRandomSampler(train_indices)
    valid_sampler = SubsetRandomSampler(val_indices)

    train_loader = DataLoader(trainset,
                              batch_size=args.batch_size,
                              sampler=train_sampler,
                              pin_memory=True,
                              drop_last=True)

    valid_loader = DataLoader(trainset,
                              batch_size=args.batch_size,
                              sampler=valid_sampler,
                              pin_memory=True,
                              drop_last=True)

    test_loader = DataLoader(testset,
                             batch_size=args.test_batch_size,
                             pin_memory=True)

    return train_loader, valid_loader, test_loader

