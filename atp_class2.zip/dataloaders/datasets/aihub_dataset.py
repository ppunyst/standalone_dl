import glob
import os

import numpy as np
from PIL import Image
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
from torchvision import transforms
from utils_.args import segmentation_parser
from utils_.mypath import Path
import cv2
import json


class AI_HUB_Dataset(Dataset):
    def __init__(self, args, split, original_size, crop_size, mean, scale):

        self.args = args
        self.object_type = self.args.object_type
        self.data_dir = Path.data_root()
        self.split = split
        self.mean = mean
        self.original_size = original_size
        self.crop_size = crop_size
        self.scale = scale
        self.files = []

        self.sample_dir = os.path.join(self.data_dir, split)

        self.input_files = glob.glob(os.path.join(self.sample_dir, f"samples/*{self.object_type}*/*png"))
        self.target_files = glob.glob(os.path.join(self.sample_dir, f"targets/*{self.object_type}*/*png"))

        self.build_colormap = [
            [0, 0, 0], # 배경(0): (0,0,0) 검정
            [0, 0, 255], #소형건물(1): (0, 0, 225) 파랑
            [255, 0, 0], #공장(3): (225, 0, 0) 빨강
            [0, 255, 0], #아파트(2): (0, 255, 0) 라임
            [0, 255, 255], #대형건물(5): (0, 225, 225) 아쿠아
            [255, 255, 0]] #중형건물(4): (225, 225, 0) 노랑

        self.test_trans = transforms.Compose([transforms.Resize((512,512))])

    def __len__(self):
        return len(self.input_files)

    def __getitem__(self, idx):
        if self.split == "test":
            img, tgr = self.input_files[idx], self.target_files[idx]
            img_rgb = Image.open(img).convert('RGB')
            tgr_rgb = Image.open(tgr).convert('RGB')

            img_rgb = self.test_trans(img_rgb)
            tgr_rgb = self.test_trans(tgr_rgb)

            if self.scale:
                crop_img = (img_rgb - self.mean) / 128

            crop_tgr = self.convert_label(tgr_rgb)
            crop_img = np.transpose(crop_img, (2, 0, 1))
            return crop_img, crop_tgr, self.input_files[idx].split("\\")[-1][:-4]

        else:
            img, tgr = self.input_files[idx], self.target_files[idx]
            img_rgb = Image.open(img).convert('RGB')
            tgr_rgb = Image.open(tgr).convert('RGB')

            if self.original_size[0] == self.crop_size[0]:
                left, top = 0, 0
            else:
                left = np.random.randint(self.original_size[0] - self.crop_size[0])
                top = np.random.randint(self.original_size[1] - self.crop_size[1])

            W = left + self.crop_size[0]
            H = top + self.crop_size[1]
            switching = np.random.rand(1)

            if switching >= 0.5:
                img_rgb = img_rgb.transpose(Image.ROTATE_180)
                tgr_rgb = tgr_rgb.transpose(Image.ROTATE_180)

            # Crop
            crop_img = img_rgb.crop((left, top, W, H))
            crop_tgr = tgr_rgb.crop((left, top, W, H))
            crop_img = np.asarray(crop_img, np.float32)
            crop_tgr = np.asarray(crop_tgr, np.float32)

            if self.scale:
                crop_img = (crop_img - self.mean) / 128

            crop_tgr = self.convert_label(crop_tgr)
            crop_img = np.transpose(crop_img, (2, 0, 1))

            return crop_img, crop_tgr, self.input_files[idx].split("\\")[-1][:-4]


    def convert_label(self, mask):
        return self.encode_segmap(np.asarray(mask))

    def encode_segmap(self, mask):
        mask = mask.astype(int)
        label_mask = np.zeros((mask.shape[0], mask.shape[1]), dtype=np.int16)

        for ii, label in enumerate(self.build_colormap):
            if ii != 0:
                label_mask[np.where(np.all(mask == label, axis=-1))[:2]] = 1
            else:
                label_mask[np.where(np.all(mask == label, axis=-1))[:2]] = ii

        return label_mask.astype(int)


if __name__ == '__main__':

    parser = segmentation_parser()
    args = parser.parse_args('')

    img_mean = np.array((128, 128, 128), dtype=np.float32)
    trainset = AI_HUB_Dataset(args=args, split='test', original_size=[1024,1024], crop_size=[512,512], mean=img_mean, scale=True)
    train_loader = DataLoader(trainset, batch_size=2)

    samples, targets, file_names = next(iter(train_loader))
