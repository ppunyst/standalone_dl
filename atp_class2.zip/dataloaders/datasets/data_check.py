import glob
import os

import numpy as np
from PIL import Image
from torch.utils.data import DataLoader
from torch.utils.data import Dataset
from torchvision import transforms
from utils_.args import segmentation_parser
from utils_.mypath import Path
import cv2
import json
import matplotlib.pyplot as plt

# define parser
parser = segmentation_parser()
args = parser.parse_args('')
data_dir = Path.data_root()
sample_dir = os.path.join(data_dir, "train")

input_files = glob.glob(os.path.join(sample_dir, f"samples/*{args.object_type}*/*png"))
target_files = glob.glob(os.path.join(sample_dir, f"targets/*{args.object_type}*/*png"))

input_size = 512
original_size = [1024, 1024]
mean = (128, 128, 128)
crop_size = [512, 512]


for i in range(input_files):
    if original_size[0] == crop_size[0]:
        left = 0
        top = 0
    else:
        left = np.random.randint(original_size[0] - crop_size[0])
        top = np.random.randint(original_size[1] - crop_size[1])

    W = left + crop_size[0]
    H = top + crop_size[1]
    switching = np.random.rand(1)


input_files[0].split("\\")[-1][:-4]

idx = 0
sample = input_files[idx]
target = target_files[idx]

if original_size[0] == crop_size[0]:
    left = 0
    top = 0
else:
    left = np.random.randint(original_size[0] - crop_size[0])
    top = np.random.randint(original_size[1] - crop_size[1])

W = left + crop_size[0]
H = top + crop_size[1]

## visualization sample & target
# sample
img_rgb = Image.open(sample).convert('RGB')
plt.imshow(img_rgb) # img_rgb.show()
img_rgb.show()
plt.show()

# target
tgr_rgb = Image.open(target).convert('RGB')
plt.imshow(tgr_rgb)
plt.show()

# crop
crop_img = img_rgb.crop((left, top, W, H))
plt.imshow(crop_img)
crop_img.show()
plt.show()

crop_trg = tgr_rgb.crop((left, top, W, H))
plt.imshow(crop_trg)
plt.show()






class AI_HUB_Dataset(Dataset):
    def __init__(self, args, split, img_transform, label_transform):
        self.args = args
        self.object_type = self.args.object_type
        self.data_dir = Path.data_root()
        self.split = split


        if self.split == "valid":
            self.sample_dir = os.path.join(self.data_dir, "train")
        else:
            self.sample_dir = os.path.join(self.data_dir, split)

        # if self.args.object_
        if self.args.object_type == 'buildings':
            self.input_files = glob.glob(os.path.join(self.sample_dir, f"samples/*{self.object_type}*/*png"))
            self.target_files = glob.glob(os.path.join(self.sample_dir, f"targets/*{self.object_type}*/*png"))
        elif self.args.object_type == 'roads':
            self.input_files = glob.glob(os.path.join(self.sample_dir, f"samples/*{self.object_type}*/*png"))
            self.target_files = glob.glob(os.path.join(self.sample_dir, f"targets/*{self.object_type}*/*json"))

            self.input_names = [i.split("\\")[-1][:-4] for i in self.input_files]
            self.target_files = [i for i in self.target_files if i.split("\\")[-1][:-5] in self.input_names]


        self.img_transform = img_transform
        self.label_transform = label_transform

        self.build_colormap = [
            [0, 0, 0], # 배경(0): (0,0,0) 검정
            [0, 0, 255], #소형건물(1): (0, 0, 225) 파랑
            [255, 0, 0], #공장(3): (225, 0, 0) 빨강
            [0, 255, 0], #아파트(2): (0, 255, 0) 라임
            [0, 255, 255], #대형건물(5): (0, 225, 225) 아쿠아
            [255, 255, 0]] #중형건물(4): (225, 225, 0) 노랑

        self.road_colorbook = {"Mortorway": (51, 51, 255),
                               "Primary": (51, 255, 255),
                               "Secondary": (51, 255, 51),
                               "Tertiary": (255, 255, 51),
                               "Residential": (255, 51, 51),
                               "Unclassified": (255, 51, 255),
                               "background": (0, 0, 0)}

        self.road_class_id = {"Mortorway": 1,
                              "Primary": 2,
                              "Secondary": 3,
                              "Tertiary": 4,
                              "Residential": 5,
                              "Unclassified": 6,
                              "background": 0}


    def __len__(self):
        return len(self.input_files)

    def __getitem__(self, idx):
        # if self.args.object_
        if self.args.object_type == 'buildings':
            X = self.input_files[idx]
            y = self.target_files[idx]

            img = Image.open(X)
            mask = Image.open(y)

            if self.img_transform:
                image = self.img_transform(img)
                mask = self.label_transform(mask)

            mask = self.convert_label(mask)

            return image, mask

        elif self.args.object_type == 'roads':
            X = self.input_files[idx]
            img = Image.open(X)

            with open(self.target_files[idx], "r") as jfile:
                meta = json.load(jfile)
            mask = self.make_mask((1024, 1024), meta)

            if self.img_transform:
                image = self.img_transform(img)
                mask = np.asarray(self.label_transform(Image.fromarray(mask)))

            return image, mask

    def make_mask(self, size, label):
        mask = np.zeros([size[0], size[1]], dtype=np.uint8)
        for r in range(len(label["features"])):
            road = label["features"][r]["properties"]
            type_name = road["type_name"]
            temp = road["road_imcoords"].split(",")
            coords = np.array([int(round(float(c))) for c in temp]).reshape(-1, 2)
            if r == 26:
                coords
            cv2.fillPoly(mask, [coords], self.road_class_id[type_name])
        return mask



    def convert_label(self, mask):
        return self.encode_segmap(np.asarray(mask))

    def encode_segmap(self, mask):
        mask = mask.astype(int)
        label_mask = np.zeros((mask.shape[0], mask.shape[1]), dtype=np.int16)

        for ii, label in enumerate(self.build_colormap):
            label_mask[np.where(np.all(mask == label, axis=-1))[:2]] = ii

        return label_mask.astype(int)


if __name__ == '__main__':

    parser = segmentation_parser()
    args = parser.parse_args('')

    img_trans = transforms.Compose([transforms.Resize((512, 512)),
                                    transforms.ToTensor()])

    label_trans = transforms.Compose([transforms.Resize((512, 512))])

    trainset = AI_HUB_Dataset(args=args, split='train', img_transform=img_trans, label_transform=label_trans)
    train_loader = DataLoader(trainset, batch_size=2)

    samples, targets = next(iter(train_loader))